import numpy as np
from scipy.optimize import fsolve
import pandas as pd

# Constants and Parameters [cite: 2-10]
a, b, d, ee, f, gg, h, k, mm, n, q, v, tax, alpha, beta, mu = \
    220, 0.7754, 2000, 1000, 0.8, 600, 1000, 0.1583, 0.1, 100, 0.75, 5, 0.1875, 0.4, 0.2, 0.33

# Time Horizon [cite: 11]
T = np.arange(16)

# Initialize Policy and Exogenous Variables [cite: 13-16]
M = np.full(16, 900.0)
G = np.full(16, 1200.0)
Yn = np.full(16, 6000.0)
Pw = np.full(16, 1.0)
Un = np.full(16, 0.05)

# --- Define Model Equations [cite: 28-42] ---
def model_equations(vars, t):
    Y, Yd, C, I, R, P, pi, piex, E, X, Gd, U = vars
    return [
        Y - (C + I + G[t] + X),                      # eq1
        Yd - (1 - tax) * Y,                          # eq2
        C - (a + b * Yd),                            # eq3
        I - (ee - d * R),                            # eq4
        M[t] / P - (k * Y - h * R),                  # eq5
        piex - (alpha * 0 + beta * 0),               # eq6
        pi - (piex + f * (Y - Yn[t]) / Yn[t]),       # eq7
        P - (1 * (1 + pi)),                          # eq8
        E * P / Pw[t] - (q + v * R),                 # eq9
        X - (gg - mm * Y - n * (E * P / Pw[t])),     # eq10
        Gd - (G[t] - tax * Y),                       # eq11
        U - (Un[t] - mu * (Y - Yn[t]) / Yn[t])       # eq12
    ]

# Solve Model [cite: 44-50]
results = []
for t in T:
    # Initial guesses [cite: 44-47]
    guess = [6500, 4875, 4500, 900, 0.09, 1.1, 0.1, 0.2, 1.2, -100, 75, 0.07]
    results.append(fsolve(model_equations, guess, args=(t,)))

# Format DataFrames to match GAMS output
df_exog = pd.DataFrame({'Money': M, 'Gov. Exp.': G, 'Pot. GDP': Yn, 'Fgn Price': Pw}, index=T)
df_endog = pd.DataFrame(results, columns=['GDP', 'DispIncome', 'Consump', 'Invest', 'IntRate', 'Price', 'Inflation', 'ExpInf', 'ExchRate', 'NetExp', 'Gov.Def', 'Unemploy'], index=T)

print("----    PARAMETER REPORTEX  POLICY AND EXOGENOUS VARIABLES VALUES")
print(df_exog.to_string())
print("\n\n----    PARAMETER REPORTS  SOLUTION VALUES IN LEVELS")
# Selecting columns to match the specific GAMS output 
cols_to_show = ['GDP', 'Inflation', 'IntRate', 'ExchRate', 'Gov.Def', 'Unemploy']
print(df_endog[cols_to_show].to_string())