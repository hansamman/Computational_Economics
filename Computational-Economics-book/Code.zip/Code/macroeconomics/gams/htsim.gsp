{
    "dynamicMainFile": false,
    "expand": "1",
    "file": "htsim.gms",
    "name": "htsim",
    "nodes": [
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "htsim.gms",
            "name": "htsim.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "htsim.lst",
            "name": "htsim.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "ownBaseDir": false,
    "path": ".",
    "pf": "",
    "projectType": 1,
    "timestamp": "2026-06-17T17:40:45.607",
    "workDir": "."
}
