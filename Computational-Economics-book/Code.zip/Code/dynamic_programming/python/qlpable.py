import numpy as np

# Title: Quadratic-Linear Tracking problem for Abel
# Converted to Python/NumPy

t = 7
n = 2
m = 2

a = np.array([[0.914, -0.016], 
              [0.097, 0.424]])
b = np.array([[0.305, 0.424], 
              [-0.101, 1.459]])
c = np.array([-59.437, -184.766])
x0 = np.array([387.9, 85.3])
xtar = np.array([387.9, 85.3])
utar = np.array([110.4, 147.17])
w = np.array([[0.0625, 0], 
              [0, 1]])
wn = np.array([[6.25, 0], 
               [0, 100]])
f = np.zeros((2, 2))
lambd = np.array([[1, 0], 
                  [0, 0.444]]) # 'lambda' is a reserved keyword in Python

# Riccati Loop Setup
kold = wn.copy()
pold = -wn @ xtar * (1.0075**t)

kstore = np.zeros((t, n, n))
pstore = np.zeros((t, n))

u = np.zeros((t + 1, m))
x = np.zeros((t + 1, n))

kstore[t-1] = kold
pstore[t-1] = pold

# Riccati Loop
k = t - 1
while k >= 1:
    factor = 1.0075**k
    utark = factor * utar
    xtark = factor * xtar
    wsmall = -w @ xtark
    lambdas = -lambd @ utark

    # Use np.linalg.solve for A \ B stability
    inv_term = np.linalg.inv(b.T @ kold @ b + lambd.T)
    
    knew = a.T @ kold @ a + w - (a.T @ kold @ b + f) @ inv_term @ (f.T + b.T @ kold @ a)
    pnew = -(a.T @ kold @ b + f) @ inv_term @ (b.T @ (kold @ c + pold) + lambdas) + \
           a.T @ (kold @ c + pold) + wsmall

    kold = knew
    pold = pnew
    kstore[k-1] = knew
    pstore[k-1] = pold
    k -= 1

# Forward loop
k = 0
xold = x0
total_sum = 0

while k <= t - 1:
    factor = 1.0075**k
    utark = factor * utar
    xtark = factor * xtar
    
    kold = kstore[k]
    pold = pstore[k]
    
    inv_term = np.linalg.inv(b.T @ kold @ b + lambd.T)
    
    glarge = -inv_term @ (f.T + b.T @ kold @ a)
    gsmall = -inv_term @ (b.T @ (kold @ c + pold) - (lambd @ utark))
    
    uopt = glarge @ xold + gsmall
    xnew = a @ xold + b @ uopt + c
    
    total_sum += 0.5 * (xold - xtark).T @ w @ (xold - xtark) + 0.5 * (uopt - utark).T @ lambd @ (uopt - utark)
    
    x[k] = xold
    u[k] = uopt
    xold = xnew
    k += 1

# Last period
x[t] = xold
total_sum += 0.5 * (xold - xtark).T @ wn @ (xold - xtark)

print("Optimal control vector:\n", u)
print("\nOptimal state vector:\n", x)
print("\nCriterion value:", total_sum)