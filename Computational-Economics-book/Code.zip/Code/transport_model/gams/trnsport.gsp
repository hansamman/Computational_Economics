{
    "dynamicMainFile": false,
    "expand": "1",
    "file": "trnsport.gms",
    "name": "trnsport",
    "nodes": [
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "trnsport.gms",
            "name": "trnsport.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "trnsport.lst",
            "name": "trnsport.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "ownBaseDir": false,
    "path": ".",
    "pf": "",
    "projectType": 1,
    "timestamp": "2026-06-17T17:37:13.884",
    "workDir": "."
}
