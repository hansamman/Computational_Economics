{
    "dynamicMainFile": false,
    "expand": "1",
    "file": "dice.gms",
    "name": "dice",
    "nodes": [
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice.gms",
            "name": "dice.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice.lst",
            "name": "dice.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "ownBaseDir": false,
    "path": ".",
    "pf": "",
    "projectType": 1,
    "timestamp": "2026-06-17T20:04:44.051",
    "workDir": "."
}
