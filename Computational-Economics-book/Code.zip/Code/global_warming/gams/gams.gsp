{
    "dynamicMainFile": false,
    "expand": "1",
    "file": "dice 2.gms",
    "name": "gams",
    "nodes": [
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice 2.gms",
            "name": "dice 2.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice 2.gsp",
            "name": "dice 2.gsp",
            "type": "gsp"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice 2.log",
            "name": "dice 2.log",
            "type": "txt"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice 2.log~1",
            "name": "dice 2.log~1",
            "type": ""
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice 2.log~2",
            "name": "dice 2.log~2",
            "type": ""
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice 2.log~3",
            "name": "dice 2.log~3",
            "type": ""
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice 2.lst",
            "name": "dice 2.lst",
            "type": "lst"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice.gms",
            "name": "dice.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice.gsp",
            "name": "dice.gsp",
            "type": "gsp"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice.log",
            "name": "dice.log",
            "type": "txt"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice.log~1",
            "name": "dice.log~1",
            "type": ""
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice.log~2",
            "name": "dice.log~2",
            "type": ""
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice.lst",
            "name": "dice.lst",
            "type": "lst"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice.lxi",
            "name": "dice.lxi",
            "type": "lxi"
        }
    ],
    "options": [
        ""
    ],
    "ownBaseDir": false,
    "path": ".",
    "pf": "",
    "projectType": 1,
    "timestamp": "2026-06-09T18:11:53.314",
    "workDir": "."
}
