{
    "dynamicMainFile": false,
    "expand": "1",
    "file": "dice.gms",
    "name": "dice 2",
    "nodes": [
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice 2.gms",
            "name": "dice 2.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice.gms",
            "name": "dice.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "encoding": "UTF-8",
            "file": "dice.lst",
            "name": "dice.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "ownBaseDir": false,
    "path": ".",
    "pf": "",
    "projectType": 1,
    "timestamp": "2026-06-09T18:09:20.364",
    "workDir": "."
}
