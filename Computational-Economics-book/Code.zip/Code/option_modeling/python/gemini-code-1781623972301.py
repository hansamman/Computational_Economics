import numpy as np
from scipy.stats import norm

# =====================================================================
# 1. BLACK-SCHOLES PRICING FUNCTIONS
# =====================================================================

def blackscholes_call(s, x, r, sigma, t):
    """Calculates the theoretical price of a European Call Option."""
    d1 = (np.log(s / x) + (r + 0.5 * sigma * sigma) * t) / (sigma * (t ** 0.5))
    d2 = (np.log(s / x) + (r - 0.5 * sigma * sigma) * t) / (sigma * (t ** 0.5))
    
    price = s * norm.cdf(d1) - x * np.exp(-r * t) * norm.cdf(d2)
    return price


def blackscholes_put(s, x, r, sigma, t):
    """Calculates the theoretical price of a European Put Option."""
    d1 = (np.log(s / x) + (r + 0.5 * sigma * sigma) * t) / (sigma * (t ** 0.5))
    d2 = (np.log(s / x) + (r - 0.5 * sigma * sigma) * t) / (sigma * (t ** 0.5))
    
    price = x * np.exp(-r * t) * norm.cdf(-d2) - s * norm.cdf(-d1)
    return price


def implied_blackscholes_call(s, x, r, sigma0, t, price):
    """Finds the implied volatility for a European Call Option."""
    eps = 1E+16
    while eps > 0.01:
        # Central difference approximation for Vega
        mylc = (blackscholes_call(s, x, r, sigma0 + 0.001, t) - \
                blackscholes_call(s, x, r, sigma0 - 0.001, t)) / 0.002
        
        sigma1 = sigma0 + (price - blackscholes_call(s, x, r, sigma0, t)) / mylc
        eps = ((sigma1 - sigma0) ** 2) / (sigma0 ** 2)
        sigma0 = sigma1
    return sigma1


# =====================================================================
# 2. BINOMIAL TREE PRICING FUNCTIONS (AMERICAN OPTIONS)
# =====================================================================

def binomial_call(s, x, r, sigma, t, nstep):
    """Computes the binomial tree for an American Call Option."""
    f = np.zeros((nstep + 1, nstep + 1))
    
    dt = t / nstep
    u = np.exp(sigma * (dt ** 0.5))
    d = 1 / u
    a = np.exp(r * dt)
    p = (a - d) / (u - d)
    
    u2 = u * u
    uloop = u ** (-nstep)
    
    # Terminal payoffs
    for j in range(nstep + 1):
        v_sum = s * uloop - x
        f[nstep, j] = max(v_sum, 0.0)
        uloop = uloop * u2
        
    # Backward induction
    for i in range(nstep - 1, -1, -1):
        uloop = u ** (-i)
        u2 = u * u
        for j in range(i + 1):
            v_sum = s * uloop - x
            sum1 = np.exp(-r * dt) * (p * f[i + 1, j + 1] + (1.0 - p) * f[i + 1, j])
            f[i, j] = max(v_sum, sum1)
            uloop = uloop * u2
            
    return f[0, 0]


def binomial_put(s, x, r, sigma, t, nstep):
    """Computes the binomial tree for an American Put Option."""
    f = np.zeros((nstep + 1, nstep + 1))
    
    dt = t / nstep
    u = np.exp(sigma * (dt ** 0.5))
    d = 1 / u
    a = np.exp(r * dt)
    p = (a - d) / (u - d)
    
    u2 = u * u
    uloop = u ** (-nstep)
    
    # Terminal payoffs
    for j in range(nstep + 1):
        v_sum = -s * uloop + x
        f[nstep, j] = max(v_sum, 0.0)
        uloop = uloop * u2
        
    # Backward induction
    for i in range(nstep - 1, -1, -1):
        uloop = u ** (-i)
        u2 = u * u
        for j in range(i + 1):
            v_sum = -s * uloop + x
            sum1 = np.exp(-r * dt) * (p * f[i + 1, j + 1] + (1.0 - p) * f[i + 1, j])
            f[i, j] = max(v_sum, sum1)
            uloop = uloop * u2
            
    return f[0, 0]


# =====================================================================
# 3. MONTE CARLO SIMULATION FUNCTIONS
# =====================================================================

def mcoption(s0, x, r, sigma, t, mcruns):
    """Prices a European Call Option using Monte Carlo simulation."""
    nsteps = 10
    dt = t / nsteps
    drift = (r - 0.5 * sigma ** 2) * dt
    
    sum1 = 0.0
    for j in range(mcruns):
        st = s0
        for i in range(nsteps):
            ds = norm.ppf(np.random.rand()) * np.sqrt(dt)
            st = st * np.exp(drift + sigma * ds)
            
        if (st - x) > 0.0:
            sum1 = sum1 + st - x
            
    price = sum1 * np.exp(-r * t) / mcruns
    return price


def american_max_option(s0, x, r, sigma, t, mcruns):
    """Prices a path-dependent option based on max path values encountered."""
    nsteps = 10
    dt = t / nsteps
    drift = (r - 0.5 * sigma ** 2) * dt
    rm = norm.ppf(np.random.rand(nsteps, mcruns))
    
    sum1 = 0.0
    for j in range(mcruns):
        smax = -1.0
        st = s0
        for i in range(nsteps):
            ds = rm[i, j] * np.sqrt(dt)
            st = st * np.exp(drift + sigma * ds)
            csum = max(0.0, st - x * np.exp(-r * (i + 1) * dt))
            if csum > smax:
                smax = csum
        sum1 = sum1 + smax
        
    price = sum1 / mcruns
    return price


# =====================================================================
# 4. EXECUTION
# =====================================================================
if __name__ == "__main__":
    # Test values from options.asv
    s, x, r, t, sigma = 42.0, 40.0, 0.1, 0.5, 0.2
    
    print(f"--- Black-Scholes Formula ---")
    print(f"Call: {blackscholes_call(s, x, r, sigma, t):.4f}")
    print(f"Put:  {blackscholes_put(s, x, r, sigma, t):.4f}\n")
    
    print(f"--- Binomial Model (10 Steps) ---")
    print(f"American Call: {binomial_call(s, x, r, sigma, t, 10):.4f}")
    print(f"American Put:  {binomial_put(s, x, r, sigma, t, 10):.4f}\n")
    
    print(f"--- Implied Volatility ---")
    print(f"Implied Vol (Target $5 Call): {implied_blackscholes_call(s, x, r, 0.1, t, 5.0):.4%}\n")
    
    print(f"--- Monte Carlo Simulation ---")
    print(f"Euro Call: {mcoption(s, x, r, sigma, t, 2000):.4f}")