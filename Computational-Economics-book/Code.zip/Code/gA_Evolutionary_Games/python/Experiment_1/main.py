import numpy as np
import matplotlib.pyplot as plt

# Parameters
NRUNS = 100
POPSIZE = 8
CLEN = 24
PMUT = 0.5

def crossover(clen, parent0, parent1):
    # Random crossover point
    crossov = np.random.randint(0, clen)
    # Create mask: bits 0 to crossov-1 are 1, others 0
    maska = (1 << crossov) - 1
    
    # Python bitwise operations
    child0 = (parent0 & maska) | (parent1 & (~maska & ((1 << clen) - 1)))
    child1 = (parent1 & maska) | (parent0 & (~maska & ((1 << clen) - 1)))
    return child0, child1

def mutation(pmut, clen, child):
    if np.random.rand() < pmut:
        idx = np.random.randint(0, clen)
        tt = 1 << idx
        # Flip the bit at idx
        child ^= tt
    return child

def fitness_gagame(genepool, popsize, clen):
    payoffs = np.zeros(popsize)
    for k1 in range(popsize):
        for k2 in range(popsize):
            if k1 != k2:
                s1 = genepool[k1]
                s2 = genepool[k2]
                for k3 in range(clen):
                    # Check individual bits
                    actionp1 = (s1 >> k3) & 1
                    actionp2 = (s2 >> k3) & 1
                    
                    if actionp1 == 0 and actionp2 == 0:   # D, D
                        payoffs[k1] += 1
                    elif actionp1 == 0 and actionp2 > 0:  # D, C
                        payoffs[k1] += 5
                    elif actionp1 > 0 and actionp2 == 0:  # C, D
                        payoffs[k1] += 0
                    else:                                 # C, C
                        payoffs[k1] += 3
    return payoffs

# Initialization
genepool = np.full(POPSIZE, (2**CLEN) - 1, dtype=np.int64)
wbest = np.zeros(NRUNS)
fbest = np.zeros(NRUNS)

# Main Loop
for k in range(NRUNS):
    fit = fitness_gagame(genepool, POPSIZE, CLEN)
    
    # Track best
    top_idx = np.argmax(fit)
    wbest[k] = genepool[top_idx]
    fbest[k] = np.max(fit)
    
    # Selection (Deterministic: top two)
    sorted_idx = np.argsort(fit)[::-1]
    parent0, parent1 = genepool[sorted_idx[0]], genepool[sorted_idx[1]]
    
    # Crossover
    child0, child1 = crossover(CLEN, parent0, parent1)
    
    # Mutation and replacement
    genenew = np.zeros(POPSIZE, dtype=np.int64)
    for h in range(0, POPSIZE, 2):
        genenew[h] = mutation(PMUT, CLEN, child0)
        genenew[h+1] = mutation(PMUT, CLEN, child1)
    genepool = genenew

# Results
print(f"Final best chromosome (binary): {bin(int(wbest[-1]))[2:].zfill(CLEN)}")

# Plotting
fbest_norm = fbest / (CLEN * (POPSIZE - 1))
plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1)
plt.plot(wbest)
plt.ylabel('Decimal representation')
plt.xlabel('Runs')
plt.subplot(1, 2, 2)
plt.plot(fbest_norm)
plt.ylabel('Average Payoffs')
plt.xlabel('Runs')
plt.show()