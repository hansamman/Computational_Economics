import numpy as np
import matplotlib.pyplot as plt

# Value function iteration for an infinite period and no uncertainty
# Model is based on the Chakravarty model as in Kendrick, Mercado and Amman (2006)
# Original MATLAB code written by Firat Yaman and modified by David Kendrick
# Python conversion

# Production coefficients, discount factor, utility parameter, depreciation
alpha = 0.33
beta = 0.98
theta = 0.3
tau = 0.5
delta = 0.1
k0 = 0.1
kN = 2.1

n = 100
k_grid = np.linspace(k0, kN, n)

# iterlim is the iteration limit 
# tolera is the tolerance for convergence
iterlim = 5
tolera = 0.000001

# Output - y-grid is the grid for output
y_grid = theta * (k_grid ** alpha)

# Vector of ones (column vector in Python)
aux = np.ones((n, 1))

# Current capital stocks vary along a row in kt_mesh
# Future capital stocks vary along a column in kt1_mesh
# i_mesh is the corresponding mesh for investment 
# since i = k(t+1) - (1-delta) * k(t)
kt_mesh = aux * k_grid
kt1_mesh = (aux * k_grid).T
i_mesh = kt1_mesh - (1 - delta) * kt_mesh

y_mesh = aux * y_grid

# Then consumption is c(t) = y(t) - i(t)
# To create the consumption mesh array
c_mesh = y_mesh - i_mesh

# Replace negative consumption with zero
c_mesh[c_mesh < 0] = 0

# Utility; to avoid negative and zero consumption we assign the lowest
# possible utility to entries with zero consumption
u_mesh = (1 / (1 - tau)) * (c_mesh ** (1 - tau))
u_mesh[c_mesh == 0] = -10

# First guess for the value function; a natural starting point is one where
# investment is zero. However, any guess will converge to the same solution.
clast = y_grid.copy()
Vlast = (1 / (1 - tau)) * (clast ** (1 - tau))

# Display the first 5 elements of Vlast to mirror MATLAB output
print("Initial Vlast (first 5 elements):")
print(Vlast[:5])

# In Python, we can leverage broadcasting, but to replicate the matrix multiplication:
Vlast_mesh = Vlast.reshape(-1, 1) @ aux.T

# Iteration, decision rules for all capital states
tol = 1.0
iter_count = 0

while (tol > tolera) and (iter_count < iterlim):
    iter_count += 1
    
    # Calculate the total value matrix
    V = u_mesh + beta * (Vlast.reshape(-1, 1) @ aux.T)
    
    # Max along axis 0 (columns) to match MATLAB's max(V, [], 1) behavior
    VV = np.max(V, axis=0)
    I = np.argmax(V, axis=0)
    
    # Convert Python's 0-based indices to MATLAB's 1-based indices for consistent plotting
    I_matlab = I + 1
    
    # Calculate differences and check convergence
    VV_diff = (VV - Vlast).reshape(-1, 1)
    tol = np.max(np.abs(VV - Vlast))
    
    # Update value function for next iteration
    Vlast = VV.copy()

# Print the results of the iteration
print("\n--- Iteration Results ---")
print(f"iter = {iter_count}")
print(f"tol = {tol}")
print(f"Vlast =\n{Vlast}")
print(f"I (1-based decision rule) =\n{I_matlab}")

# Plotting the decision rule for the capital stock
# MATLAB's 1:n translates to 1 to n inclusive
index = np.arange(1, n + 1)

plt.figure(1)
plt.plot(index, index, '-', label='steady state')
plt.plot(index, I_matlab, '--', label='decision rule')
plt.title('Path of capital')
plt.legend()
plt.show()