import numpy as np
import matplotlib.pyplot as plt

# Value function iteration for an infinite period and uncertainty
# Model is based on the Chakravarty model as in Kendrick, Mercado and Amman (2006)
# Original MATLAB code written by Firat Yaman and modified by David Kendrick
# Python conversion

# Production coefficients, discount factor, utility parameter, depreciation
alpha = 0.33
beta = 0.98
theta = 0.3
tau = 0.5
delta = 0.1
k0 = 0.1
kN = 2.1
n = 100

# Grid for capital
k_grid = np.linspace(k0, kN, n)

iterlim = 5
tolera = 0.000001

z_low = 0.90;
z_high = 1.10;  

# Probability matrix P
# P[0,0]: low to low, P[0,1]: low to high
# P[1,0]: high to low, P[1,1]: high to high
P = np.zeros((2, 2))
P[0, 0] = 0.5
P[0, 1] = 1 - P[0, 0]
P[1, 0] = 0.1
P[1, 1] = 1 - P[1, 0]

# Output - y-grid is the grid for output
y_grid_l = z_low * theta * (k_grid ** alpha)
y_grid_h = z_high * theta * (k_grid ** alpha)

# Vector of ones (column vector in Python)
aux = np.ones((n, 1))

# Reshaping k_grid for broadcasting/mesh creation
# In Python, we can use broadcasting instead of explicit matrix multiplication with ones
kt_mesh = aux * k_grid                  # current capital stocks vary along rows
kt1_mesh = (aux * k_grid).T             # future capital stocks vary along columns
i_mesh = kt1_mesh - (1 - delta) * kt_mesh

y_mesh_l = aux * y_grid_l
y_mesh_h = aux * y_grid_h

# Consumption mesh array: c(t) = y(t) - i(t)
c_mesh_l = y_mesh_l - i_mesh
c_mesh_h = y_mesh_h - i_mesh

# Replace negative consumption with zero
c_mesh_l[c_mesh_l < 0] = 0
c_mesh_h[c_mesh_h < 0] = 0

# Utility; avoid negative and zero consumption by assigning lowest possible utility
u_mesh_l = (1 / (1 - tau)) * (c_mesh_l ** (1 - tau))
u_mesh_l[c_mesh_l == 0] = -10

u_mesh_h = (1 / (1 - tau)) * (c_mesh_h ** (1 - tau))
u_mesh_h[c_mesh_h == 0] = -10

# First guess for the value function (no investment, consumption = output)
clast_l = y_grid_l.copy()
Vlast_l = (1 / (1 - tau)) * (clast_l ** (1 - tau))

clast_h = y_grid_h.copy()
Vlast_h = (1 / (1 - tau)) * (clast_h ** (1 - tau))

# Iteration loop
tol = 1.0
iter_count = 0

while (tol > tolera) and (iter_count < iterlim):
    iter_count += 1
    
    # Value matrix generation (broadcasting aux.T equivalent)
    V_l = u_mesh_l + beta * (P[0, 0] * Vlast_l.reshape(-1, 1) @ aux.T + P[0, 1] * Vlast_h.reshape(-1, 1) @ aux.T)
    V_h = u_mesh_h + beta * (P[1, 0] * Vlast_l.reshape(-1, 1) @ aux.T + P[1, 1] * Vlast_h.reshape(-1, 1) @ aux.T)
    
    # Max along axis 0 (columns) to match MATLAB's max(V, [], 1) behavior 
    # Note: Python's argmax returns 0-based indices. 
    VV_l = np.max(V_l, axis=0)
    I_l = np.argmax(V_l, axis=0)
    
    # MATLAB indices are 1-based. To perfectly match the output for plotting, add 1:
    I_l_matlab = I_l + 1 
    
    VV_h = np.max(V_h, axis=0)
    I_h = np.argmax(V_h, axis=0)
    I_h_matlab = I_h + 1

    tol_l = np.max(np.abs(VV_l - Vlast_l))
    tol_h = np.max(np.abs(VV_h - Vlast_h))
    tol = max(tol_l, tol_h)
    
    Vlast_l = VV_l.copy()
    Vlast_h = VV_h.copy()

# Output results to console
print(f"iter = {iter_count}")
print(f"tol = {tol}")
print(f"Vlast_l =\n{Vlast_l}")
print(f"Vlast_h =\n{Vlast_h}")
print(f"I_l (1-based) =\n{I_l_matlab}")
print(f"I_h (1-based) =\n{I_h_matlab}")

# Plotting the decision rule
# MATLAB's 1:n map translates to 1 to n inclusive
index = np.arange(1, n + 1)

plt.figure(1)
plt.plot(index, index, '-', label='steady state')
plt.plot(index, I_l_matlab, '--', label='decision rule low')
plt.plot(index, I_h_matlab, ':', label='decision rule high')
plt.title('Path of capital')
plt.legend()
plt.show()