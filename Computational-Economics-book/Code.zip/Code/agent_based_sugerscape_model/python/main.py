import numpy as np
import matplotlib.pyplot as plt

# Configuration
SIZE = 50
NRUNS = 6
METABOLISM_V = 4
VISION_V = 6
MAX_SUGAR = 20

def init_sugarscape(size, maxsugar):
    """Generates a two-peak sugarscape."""
    x = np.arange(-int(0.75 * size), size - int(0.75 * size))
    y = np.arange(-int(0.25 * size), size - int(0.25 * size))
    X, Y = np.meshgrid(x, y)
    
    # Calculate peaks (avoid division by zero at origin)
    s1 = maxsugar / (np.abs(X) + np.abs(Y) + 1e-9)
    s = s1 + s1.T
    return s

class Agent:
    def __init__(self, metabolism, vision, wealth):
        self.active = True
        self.metabolism = metabolism
        self.vision = vision
        self.wealth = wealth

# Initialize environment
s = init_sugarscape(SIZE, MAX_SUGAR)
agents = np.empty((SIZE, SIZE), dtype=object)

# Initialize agents
for i in range(SIZE):
    for j in range(SIZE):
        if np.random.rand() < 0.2:
            agents[i, j] = Agent(
                metabolism=np.random.randint(1, METABOLISM_V + 1),
                vision=np.random.randint(1, VISION_V + 1),
                wealth=s[i, j]
            )

def get_best_move(i, j, agent, s, agents):
    best_s = s[i, j]
    best_pos = (i, j)
    
    # Check vision range in 4 cardinal directions
    for dist in range(1, agent.vision + 1):
        for di, dj in [(0, dist), (0, -dist), (dist, 0), (-dist, 0)]:
            ni, nj = (i + di) % SIZE, (j + dj) % SIZE
            if agents[ni, nj] is None:
                if s[ni, nj] > best_s:
                    best_s = s[ni, nj]
                    best_pos = (ni, nj)
    return best_pos, best_s

# Main Simulation Loop
for run in range(NRUNS):
    # Visualize
    plt.subplot(2, 3, run + 1)
    plt.spy(agents != None)
    plt.title(f"Run {run+1}")
    
    # Process agents
    indices = [(i, j) for i in range(SIZE) for j in range(SIZE)]
    np.random.shuffle(indices)
    
    for i, j in indices:
        agent = agents[i, j]
        if agent and agent.active:
            (ni, nj), best_s = get_best_move(i, j, agent, s, agents)
            
            # Move or stay
            if (ni, nj) != (i, j):
                agents[ni, nj] = agent
                agents[i, j] = None
                i, j = ni, nj
            
            # Eat and update
            agent.wealth += best_s - agent.metabolism
            if agent.wealth <= 0:
                agents[i, j] = None

plt.show()