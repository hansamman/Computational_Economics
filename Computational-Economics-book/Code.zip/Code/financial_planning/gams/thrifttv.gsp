{
    "file": "thrifttv.gms",
    "name": "thrifttv",
    "nodes": [
        {
            "codecMib": 106,
            "file": "thrifttv.gms",
            "name": "thrifttv.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "file": "thrifttv.lst",
            "name": "thrifttv.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "path": ".",
    "pf": "",
    "workDir": "."
}
