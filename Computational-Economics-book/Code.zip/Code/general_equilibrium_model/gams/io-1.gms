$TITLE IO-1 
* Input-Output Model
* developed by Ruben Mercado

 
SCALARS 
d1 final demand for x1  /4/ 
d2 final demand for x2  /5/ 
d3 final demand for x3  /3/; 
 
VARIABLES 
x1 production level industry 1 
x2 production level industry 2 
x3 production level industry 3 
j  performance index; 
 
EQUATIONS 
eqx1 
eqx2 
eqx3 
jd performance index definition; 
 
jd..    j =E= 0; 
eqx1.. x1 =E= 0.3*x1 + 0.2*x2 + 0.2*x3 + d1; 
eqx2.. x2 =E= 0.1*x1 + 0.4*x2 + 0.5*x3 + d2; 
eqx3.. x3 =E= 0.4*x1 + 0.1*x2 + 0.2*x3 + d3; 
 
MODEL IO /jd, eqx1, eqx2, eqx3/; 
 
SOLVE IO MAXIMIZING J USING LP; 
 
DISPLAY x1.l, x2.l, x3.l; 
