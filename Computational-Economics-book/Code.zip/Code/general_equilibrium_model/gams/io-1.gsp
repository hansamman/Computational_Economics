{
    "file": "io-1.gms",
    "name": "io-1",
    "nodes": [
        {
            "codecMib": 106,
            "file": "io-1.gms",
            "name": "io-1.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "file": "io-1.lst",
            "name": "io-1.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "path": ".",
    "pf": "",
    "workDir": "."
}
