$TITLE SIMPLEGE 
* Developed by Ruben Mercado

* option NLP=MINOS;
* NOTE to PC USERS: Remove the asterisk from the above line.
* i.e., on PC this code must be run with the option NLP=MINOS. 
 
SCALARS 
a labor share / 0.7 / 
b technology parameter / 1.2 /; 
 
POSITIVE VARIABLES 
qs good supply 
qd good demand 
ld labor demand 
ls labor supply 
kd capital demand 
ks capital supply 
p price 
w wage 
r profit 
y income; 
 
VARIABLES 
j  performance index; 
 
EQUATIONS 
eqs good supply equation (production funcion) 
eqd good demand equation 
eld labor demand equation 
els labor supply equation 
ekd capital demand equation 
eks capital supply equation 
ey  income equation 
eml labor market clearing 
emk capital market clearing 
jd performance index definition; 
 
jd..       j =E= 0; 
 
eqs..     qs =E= b * ld**a * kd**(1-a); 
eld..     ld =E= a * qs * p / w; 
els..     ls =E= 2; 
eml..     ld =E= ls; 
ekd..     kd =E= (1-a)* qs * p / r; 
eks..     ks =E= 1; 
emk..     kd =E= ks; 
ey..       y =E= w * ld + r * kd; 
eqd..     qd =E= y / p; 
 
*lower bounds to avoid division by zero 
p.lo = 0.001;  w.lo = 0.001;  r.lo = 0.001; 
 
*numeraire 
p.fx = 1; 
 
MODEL SIMPLEGE /all/; 
SOLVE SIMPLEGE MAXIMIZING J USING NLP; 
DISPLAY qs.l, qd.l, ld.l, ls.l, kd.l, ks.l, p.l, w.l, r.l, y.l;
