$TITLE IO-2 
* Input-Output Model with restrictions 
* Developed by Ruben Mercado
 
SCALARS 
d2 final demand for x2  /5/ 
d3 final demand for x3  /3/; 
 
POSITIVE VARIABLES 
x1 production level industry 1 
x2 production level industry 2 
x3 production level industry 3 
d1 final demand for x1; 
 
VARIABLES 
j  performance index; 
 
EQUATIONS 
eqx1 
eqx2 
eqx3 
res1 restriction 1 
res2 restriction 2 
jd performance index definition; 
 
jd..    j =E= d1; 
eqx1.. x1 =E= 0.3*x1 + 0.2*x2 + 0.2*x3 + d1; 
eqx2.. x2 =E= 0.1*x1 + 0.4*x2 + 0.5*x3 + d2; 
eqx3.. x3 =E= 0.4*x1 + 0.1*x2 + 0.2*x3 + d3; 
res1.. x2 =L= 22; 
res2.. x3 =L= 14; 
 
MODEL IO /all/; 
 
SOLVE IO MAXIMIZING j USING LP; 
 
DISPLAY x1.l, x2.l, x3.l, d1.l; 
