{
    "file": "io-2.gms",
    "name": "io-2",
    "nodes": [
        {
            "codecMib": 106,
            "file": "io-2.gms",
            "name": "io-2.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "file": "io-2.lst",
            "name": "io-2.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "path": ".",
    "pf": "",
    "workDir": "."
}
