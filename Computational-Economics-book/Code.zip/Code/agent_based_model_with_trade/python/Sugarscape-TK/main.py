import numpy as np
import matplotlib.pyplot as plt

# =============================================================================
# 1. AGENT CLASS DEFINITION
# =============================================================================
class Agent:
    """Represents an individual agent on the Sugarscape grid with specific 
    metabolic parameters, resource wealth levels, and cultural tags."""
    def __init__(self, active=False, metsugar=0, metspice=0, vision=0, 
                 wealthsugar=0.0, wealthspice=0.0, tagstring=None, fR=0.0, group=''):
        self.active = active
        self.metsugar = metsugar
        self.metspice = metspice
        self.vision = vision
        self.wealthsugar = wealthsugar
        self.wealthspice = wealthspice
        self.tagstring = tagstring if tagstring is not None else np.array([])
        self.fR = fR
        self.group = group

# =============================================================================
# 2. ENVIRONMENT AND POPULATION INITIALIZATION FUNCTIONS
# =============================================================================
def initsugarscapeTb(size_dim, maxresource, x, y):
    """Generates a base grid with a single peak resource distribution using Manhattan distance."""
    stemp = np.zeros((size_dim, size_dim))
    for i in range(size_dim):
        for j in range(size_dim):
            if x[i] == 0 and y[j] == 0:
                stemp[i, j] = maxresource
            else:
                stemp[i, j] = maxresource / (abs(x[i]) + abs(y[j]))
    return stemp

def initsugarscapeT(size_dim, maxsugar, maxspice):
    """Creates the four-peak landscape combining two goods: Sugar and Spice."""
    q75 = int(np.ceil(0.75 * size_dim))
    q25 = int(np.ceil(0.25 * size_dim))
    
    # Sugar Peaks (South West and North East)
    x1, y1 = np.arange(-q75, size_dim - q75), np.arange(-q25, size_dim - q25)
    s1 = initsugarscapeTb(size_dim, maxsugar, x1, y1)
    
    x2, y2 = np.arange(-q25, size_dim - q25), np.arange(-q75, size_dim - q75)
    s2 = initsugarscapeTb(size_dim, maxsugar, x2, y2)
    ssugar = s1 + s2
    
    # Spice Peaks (South East and North West)
    x3, y3 = np.arange(-q75, size_dim - q75), np.arange(-q75, size_dim - q75)
    s3 = initsugarscapeTb(size_dim, maxspice, x3, y3)
    
    x4, y4 = np.arange(-q25, size_dim - q25), np.arange(-q25, size_dim - q25)
    s4 = initsugarscapeTb(size_dim, maxspice, x4, y4)
    sspice = s3 + s4
    
    s = ssugar - sspice
    return s, ssugar, sspice

def initagentsTK(size_dim, vision, metsugar, metspice, initwup, initwlow, stl):
    """Populates approximately 30% of the grid cells with newly initialized agents."""
    grid = np.empty((size_dim, size_dim), dtype=object)
    for i in range(size_dim):
        for j in range(size_dim):
            if np.random.rand() < 0.3:
                # Construct cultural tag arrays containing 'R' or 'G' characters
                tags = np.array(['R' if np.random.rand() > 0.5 else 'G' for _ in range(stl)])
                fR_val = np.sum(tags == 'R') / stl
                group_val = 'R' if fR_val > 0.5 else 'G'
                
                grid[i, j] = Agent(
                    active=True,
                    metsugar=int(np.ceil(np.random.rand() * metsugar)),
                    metspice=int(np.ceil(np.random.rand() * metspice)),
                    vision=int(np.ceil(np.random.rand() * vision)),
                    wealthsugar=np.random.rand() * (initwup - initwlow) + initwlow,
                    wealthspice=np.random.rand() * (initwup - initwlow) + initwlow,
                    tagstring=tags,
                    fR=fR_val,
                    group=group_val
                )
            else:
                grid[i, j] = Agent(active=False)
    return grid

def dispagentlocTK(grid, size_dim, nruns, runs, groupR):
    """Tracks demographic information and renders sparsity pattern plots for specific milestones."""
    a = np.zeros((size_dim, size_dim))
    count_R = 0
    for i in range(size_dim):
        for j in range(size_dim):
            if grid[i, j].active:
                a[i, j] = 1
                if grid[i, j].group == 'R':
                    count_R += 1
                    
    groupR[runs - 1] = count_R
    
    # Replicate the MATLAB conditional checkpoint figures using Matplotlib
    if runs in [1, 5, 10, 50, 100, nruns]:
        plt.figure()
        plt.spy(a, markersize=3, color='black')
        plt.title(f"Agent Locations Spatial Layout - Run {runs}")
        plt.gca().set_aspect('equal', adjustable='box')
        plt.grid(True, linestyle=':', alpha=0.5)
        
    return groupR, grid

# =============================================================================
# 3. SPATIAL MOVEMENT PIPELINE (seeW & neighborWK)
# =============================================================================
def neighborWK(u, v, grid, ssugar, sspice, tempssugar, tempsspice, tempi, tempj, i, j):
    """Evaluates individual target coordinates to find optimal welfare options."""
    move = 'not'
    if not grid[u, v].active:
        agent = grid[i, j]
        wsu, wsp = agent.wealthsugar, agent.wealthspice
        msu, msp = agent.metsugar, agent.metspice
        f = agent.fR
        mtot = msu * f + msp * (1 - f)
        
        if mtot == 0:
            mtot = 0.001
            
        welfareij = ((wsu + ssugar[i, j]) ** ((msu / mtot) * f)) * \
                    ((wsp + sspice[i, j]) ** ((msp / mtot) * (1 - f)))
                    
        welfareuv = ((wsu + ssugar[u, v]) ** ((msu / mtot) * f)) * \
                    ((wsp + sspice[u, v]) ** ((msp / mtot) * (1 - f)))
                    
        if welfareuv >= welfareij:
            move = 'yes'
            tempssugar = ssugar[u, v]
            tempsspice = sspice[u, v]
            tempi = u
            tempj = v
            
    return tempssugar, tempsspice, tempi, tempj, move

def seeW(i, j, k, grid, ssugar, sspice, size_dim, tempssugar, tempsspice, tempi, tempj):
    """Scans all four cardinal directions utilizing native Python modulo for toroidal wrapping."""
    directions = [
        ((i + k) % size_dim, j),  # South
        ((i - k) % size_dim, j),  # North
        (i, (j + k) % size_dim),  # East
        (i, (j - k) % size_dim)   # West
    ]
    
    move = 'not'
    for idx in np.random.permutation(4):
        u, v = directions[idx]
        tempssugar, tempsspice, tempi, tempj, move2 = neighborWK(
            u, v, grid, ssugar, sspice, tempssugar, tempsspice, tempi, tempj, i, j
        )
        if move2 == 'yes':
            move = 'yes'
            
    return tempssugar, tempsspice, tempi, tempj, move

def moveagentT(grid, i, j, tempssugar, tempsspice, tempi, tempj, move):
    """Relocates agents to targeted coordinates and subtracts required standard metabolisms."""
    if move == 'yes':
        grid[tempi, tempj] = grid[i, j]
        grid[i, j] = Agent(active=False)
        
        grid[tempi, tempj].wealthsugar += tempssugar - grid[tempi, tempj].metsugar
        grid[tempi, tempj].wealthspice += tempsspice - grid[tempi, tempj].metspice
        
        if grid[tempi, tempj].wealthsugar <= 0 or grid[tempi, tempj].wealthspice <= 0:
            grid[tempi, tempj] = Agent(active=False)
    else:
        grid[i, j].wealthsugar += tempssugar - grid[i, j].metsugar
        grid[i, j].wealthspice += tempsspice - grid[i, j].metspice
        
        if grid[i, j].wealthsugar <= 0 or grid[i, j].wealthspice <= 0:
            grid[i, j] = Agent(active=False)
            
    return grid

# =============================================================================
# 4. COMMERCE AND CULTURE EXCHANGE PIPELINE (seeTK & neighborTK)
# =============================================================================
def neighborTK(u, v, grid, i, j, stl):
    """Executes cultural tags reconciliation processes followed by resource commerce processing."""
    aptv = 0.0
    ptv = []
    
    if grid[u, v].active:
        # --- Section A: Cultural Convergence Process ---
        veca = grid[i, j].tagstring.copy()
        vecb = grid[u, v].tagstring.copy()
        
        n = np.random.randint(0, stl)
        vecb[n] = veca[n]
        grid[u, v].tagstring = vecb
        
        fa = grid[i, j].fR
        fb = np.sum(vecb == 'R') / stl
        grid[u, v].fR = fb
        grid[u, v].group = 'R' if fb > 0.5 else 'G'
        
        # --- Section B: Multi-Commodity Trade Routine ---
        owsua, owspa = grid[i, j].wealthsugar, grid[i, j].wealthspice
        owsub, owspb = grid[u, v].wealthsugar, grid[u, v].wealthspice
        
        msua, mspa = grid[i, j].metsugar, grid[i, j].metspice
        msub, mspb = grid[u, v].metsugar, grid[u, v].metspice
        
        mtota = msua * fa + mspa * (1 - fa)
        mtotb = msub * fb + mspb * (1 - fb)
        
        if mtota == 0: mtota = 0.001
        if mtotb == 0: mtotb = 0.001
        
        if owspa > 0 and owsua > 0 and owsub > 0 and owspb > 0:
            signalloop = 1
            waold = (owsua ** ((msua / mtota) * fa)) * (owspa ** ((mspa / mtota) * (1 - fa)))
            wbold = (owsub ** ((msub / mtotb) * fb)) * (owspb ** ((mspb / mtotb) * (1 - fb)))
            
            denom_a = (owsua / (msua * fa)) if (msua * fa) != 0 else 0.001
            omrsa = (owspa / (mspa * (1 - fa))) / denom_a if (mspa * (1 - fa)) != 0 else 0.001
            
            denom_b = (owsub / (msub * fb)) if (msub * fb) != 0 else 0.001
            omrsb = (owspb / (mspb * (1 - fb))) / denom_b if (mspb * (1 - fb)) != 0 else 0.001
            
            if omrsa > omrsb:     signalmrsold = '>'
            elif omrsa < omrsb:   signalmrsold = '<'
            else:                 signalloop = 0
        else:
            signalloop = 0
            
        while signalloop >= 1:
            p = (omrsa * omrsb) ** 0.5
            qsu = 1.0 if p > 1 else 1.0 / p
            qsp = p if p > 1 else 1.0
            
            if signalmrsold == '>':
                qsua, qspa, qsub, qspb = qsu, -qsp, -qsu, qsp
            else:
                qsua, qspa, qsub, qspb = -qsu, qsp, qsu, -qsp
                
            nwsua = owsua + qsua
            nwspa = owspa + qspa
            nwsub = owsub + qsub
            nwspb = owspb + qspb
            
            if nwsua > 0 and nwspa > 0 and nwsub > 0 and nwspb > 0:
                wanew = (nwsua ** ((msua / mtota) * fa)) * (nwspa ** ((mspa / mtota) * (1 - fa)))
                wbnew = (nwsub ** ((msub / mtotb) * fb)) * (nwspb ** ((mspb / mtotb) * (1 - fb)))
                
                if wanew > waold and wbnew > wbold:
                    denom_na = (nwsua / (msua * fa)) if (msua * fa) != 0 else 0.001
                    nmrsa = (nwspa / (mspa * (1 - fa))) / denom_na if (mspa * (1 - fa)) != 0 else 0.001
                    
                    denom_nb = (nwsub / (msub * fb)) if (msub * fb) != 0 else 0.001
                    nmrsb = (nwspb / (mspb * (1 - fb))) / denom_nb if (mspb * (1 - fb)) != 0 else 0.001
                    
                    if nmrsa > nmrsb:     signalmrsnew = '>'
                    elif nmrsa < nmrsb:   signalmrsnew = '<'
                    else:                 signalmrsnew = '='
                        
                    if signalmrsold == signalmrsnew and signalloop != 0:
                        owsua, owspa = nwsua, nwspa
                        owsub, owspb = nwsub, nwspb
                        omrsa, omrsb = nmrsa, nmrsb
                        waold, wbold = wanew, wbnew
                        
                        ptv.append(p)
                        aptv = np.exp(np.mean(np.log(ptv)))
                        
                        # FIXED ASSIGNMENT BUG FROM THE ORIGINAL MATLAB CODE
                        grid[i, j].wealthsugar = nwsua
                        grid[i, j].wealthspice = nwspa
                        grid[u, v].wealthsugar = nwsub
                        grid[u, v].wealthspice = nwspb
                    else:
                        signalloop = 0
                else:
                    signalloop = 0
            else:
                signalloop = 0
                
    return aptv, grid

def seeTK(i, j, k, grid, size_dim, stl):
    """Investigates visual boundaries searching for local neighbor trade candidates."""
    directions = [
        ((i + k) % size_dim, j),
        ((i - k) % size_dim, j),
        (i, (j + k) % size_dim),
        (i, (j - k) % size_dim)
    ]
    
    pav = []
    avpav = 0.0
    for idx in np.random.permutation(4):
        u, v = directions[idx]
        aptv, grid = neighborTK(u, v, grid, i, j, stl)
        if aptv > 0:
            pav.append(aptv)
            
    if len(pav) > 0:
        avpav = np.exp(np.mean(np.log(pav)))
        
    return avpav, grid

# =============================================================================
# 5. EXECUTION PIPELINE MAIN ENGINE
# =============================================================================
if __name__ == "__main__":
    # Simulation Hyperparameters
    nruns = 400 
    size_dim = 50 
    metsugar = 5
    metspice = 5
    vision = 5 
    maxsugar = 30
    maxspice = 30 
    initwup = 50
    initwlow = 25
    stl = 25 
    
    groupR = np.zeros(nruns)
    avprruns = np.zeros(nruns)
    axesx = np.zeros(nruns)
    
    # Grid initialization
    s, ssugar, sspice = initsugarscapeT(size_dim, maxsugar, maxspice)
    grid = initagentsTK(size_dim, vision, metsugar, metspice, initwup, initwlow, stl)
    
    # Core loop
    for runs in range(1, nruns + 1):
        prv = []
        groupR, grid = dispagentlocTK(grid, size_dim, nruns, runs, groupR)
        
        # Shuffle coordinates row/column access sequences randomly
        for i in np.random.permutation(size_dim):
            for j in np.random.permutation(size_dim):
                if grid[i, j].active:
                    tempssugar = ssugar[i, j]
                    tempsspice = sspice[i, j]
                    tempi, tempj = i, j
                    
                    # Phase 1: Spatial Rule M execution
                    move = 'not'
                    for k in range(grid[i, j].vision, 0, -1):
                        tempssugar, tempsspice, tempi, tempj, k_move = seeW(
                            i, j, k, grid, ssugar, sspice, size_dim, tempssugar, tempsspice, tempi, tempj
                        )
                        if k_move == 'yes':
                            move = 'yes'
                            
                    grid = moveagentT(grid, i, j, tempssugar, tempsspice, tempi, tempj, move)
                    
                    # Phase 2: Rules T & K execution (evaluate using current position coordinate context)
                    if grid[tempi, tempj].active:
                        for k in range(grid[tempi, tempj].vision, 0, -1):
                            avpav, grid = seeTK(tempi, tempj, k, grid, size_dim, stl)
                            if avpav > 0:
                                prv.append(avpav)
                                
        # Apply geometric metrics calculation safeguards
        if len(prv) > 0:
            avprv = np.exp(np.mean(np.log(prv)))
        else:
            avprv = 1.0
            
        avprruns[runs - 1] = avprv
        axesx[runs - 1] = runs
        
        if runs % 20 == 0 or runs == 1 or runs == nruns:
            print(f"Cycle Iteration {runs:03d}/{nruns:03d} -> Active 'R' Agents: {int(groupR[runs-1]):03d} | Geo Mean Price: {avprv:.4f}")

    # =============================================================================
    # 6. HISTORICAL PLOTS AND SUMMARY METRICS DISPLAY
    # =============================================================================
    # Figure 3: Average Market Price Progression Curve
    plt.figure(3)
    plt.scatter(axesx, avprruns, color='crimson', edgecolor='black', alpha=0.6, label='Iterative Price Points')
    plt.plot(axesx, avprruns, color='black', alpha=0.4, linestyle='--')
    plt.title("Sugarscape Market Prices Vector Summary (Figure 3)")
    plt.xlabel("Timeline Simulation Runs")
    plt.ylabel("Geometric Mean Market Trading Price")
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend()

    # Figure 4: Cultural Group Population Progression Tracker
    plt.figure(4)
    plt.scatter(axesx, groupR, color='dodgerblue', edgecolor='black', alpha=0.6, label="Group R Population")
    plt.plot(axesx, groupR, color='black', alpha=0.4, linestyle='--')
    plt.title("Cultural Group Evolution Tracker (Figure 4)")
    plt.xlabel("Timeline Simulation Runs")
    plt.ylabel("Total Count of Active Agents in 'R' Culture Class")
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend()

    plt.show()