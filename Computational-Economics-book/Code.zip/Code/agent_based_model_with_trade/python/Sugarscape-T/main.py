import numpy as np
import matplotlib.pyplot as plt

# =============================================================================
# AGENT OBJECT DEFINITION
# =============================================================================
class Agent:
    def __init__(self, active=False, metsugar=0, metspice=0, vision=0, wealthsugar=0, wealthspice=0):
        self.active = active
        self.metsugar = metsugar
        self.metspice = metspice
        self.vision = vision
        self.wealthsugar = wealthsugar
        self.wealthspice = wealthspice

# =============================================================================
# LANDSCAPE AND POPULATION INITIALIZATION FUNCTIONS
# =============================================================================

def initsugarscapeTb(size_dim, maxresource, x, y):
    """Generates a Single-Peak Sugarscape grid layout based on Manhattan distance."""
    stemp = np.zeros((size_dim, size_dim))
    for i in range(size_dim):
        for j in range(size_dim):
            if x[i] == 0 and y[j] == 0:
                stemp[i, j] = maxresource
            else:
                stemp[i, j] = maxresource / (abs(x[i]) + abs(y[j]))
    return stemp

def initsugarscapeT(size_dim, maxsugar, maxspice):
    """Initializes the multi-peak Sugar and Spice landscape environment grid."""
    q75 = int(np.ceil(0.75 * size_dim))
    q25 = int(np.ceil(0.25 * size_dim))
    
    # Sugar Peak 1 (South West)
    x1 = np.arange(-q75, size_dim - q75)
    y1 = np.arange(-q25, size_dim - q25)
    s1 = initsugarscapeTb(size_dim, maxsugar, x1, y1)
    
    # Sugar Peak 2 (North East)
    x2 = np.arange(-q25, size_dim - q25)
    y2 = np.arange(-q75, size_dim - q75)
    s2 = initsugarscapeTb(size_dim, maxsugar, x2, y2)
    
    ssugar = s1 + s2
    
    # Spice Peak 1 (South East)
    x3 = np.arange(-q75, size_dim - q75)
    y3 = np.arange(-q75, size_dim - q75)
    s3 = initsugarscapeTb(size_dim, maxspice, x3, y3)
    
    # Spice Peak 2 (North West)
    x4 = np.arange(-q25, size_dim - q25)
    y4 = np.arange(-q25, size_dim - q25)
    s4 = initsugarscapeTb(size_dim, maxspice, x4, y4)
    
    sspice = s3 + s4
    s = ssugar - sspice
    
    # Display Map Landscape Distribution
    plt.figure(2)
    plt.imshow(s, cmap='coolwarm', origin='lower')
    plt.title("Four-peak Sugar & Spice Grid Map")
    plt.colorbar()
    plt.draw()
    plt.pause(0.1)
    
    return s, ssugar, sspice

def initagentsT(size_dim, vision, metsugar, metspice, initwup, initwlow):
    """Initializes the structural grid environment population randomly with Agents."""
    grid = np.empty((size_dim, size_dim), dtype=object)
    for i in range(size_dim):
        for j in range(size_dim):
            if np.random.rand() < 0.3:
                grid[i, j] = Agent(
                    active=True,
                    metsugar=int(np.ceil(np.random.rand() * metsugar)),
                    metspice=int(np.ceil(np.random.rand() * metspice)),
                    vision=int(np.ceil(np.random.rand() * vision)),
                    wealthsugar=np.random.rand() * (initwup - initwlow) + initwlow,
                    wealthspice=np.random.rand() * (initwup - initwlow) + initwlow
                )
            else:
                grid[i, j] = Agent(active=False)
    return grid

def dispagentlocT(grid, size_dim, nruns, runs):
    """Visualizes current locations of active elements across milestone thresholds."""
    milestones = [1, 5, 10, 50, 100, nruns]
    if runs in milestones:
        a = np.zeros((size_dim, size_dim))
        for i in range(size_dim):
            for j in range(size_dim):
                if grid[i, j].active:
                    a[i, j] = 1
                    
        plt.figure(100 + runs)
        plt.spy(a, markersize=2)
        plt.title(f"Agent Locations Spatial State - Step: {runs}")
        plt.gca().set_aspect('equal', adjustable='box')
        plt.draw()
        plt.pause(0.1)

# =============================================================================
# MOVEMENT BEHAVIOR FUNCTIONS
# =============================================================================

def neighborW(u, v, grid, ssugar, sspice, tempssugar, tempsspice, tempi, tempj, i, j):
    """Evaluates individual destination cells to measure potential welfare adjustments."""
    move = 'not'
    if not grid[u, v].active:
        agent = grid[i, j]
        mtot = agent.metspice + agent.metsugar
        
        # Welfare calculation metric formula matching rule Ginf
        welfareij = ((agent.wealthsugar + ssugar[i, j]) ** (agent.metsugar / mtot)) * \
                    ((agent.wealthspice + sspice[i, j]) ** (agent.metspice / mtot))
                    
        welfareuv = ((agent.wealthsugar + ssugar[u, v]) ** (agent.metsugar / mtot)) * \
                    ((agent.wealthspice + sspice[u, v]) ** (agent.metspice / mtot))
        
        if welfareuv >= welfareij:
            move = 'yes'
            tempssugar = ssugar[u, v]
            tempsspice = sspice[u, v]
            tempi = u
            tempj = v
            
    return tempssugar, tempsspice, tempi, tempj, move

def seeW(i, j, k, grid, ssugar, sspice, size_dim, tempssugar, tempsspice, tempi, tempj):
    """Scans all four directional cardinal points within Toroidal/Periodic spaces."""
    directions = [
        ((i + k) % size_dim, j),  # South
        ((i - k) % size_dim, j),  # North
        (i, (j + k) % size_dim),  # East
        (i, (j - k) % size_dim)   # West
    ]
    
    move = 'not'
    for idx in np.random.permutation(4):
        u, v = directions[idx]
        tempssugar, tempsspice, tempi, tempj, d_move = neighborW(
            u, v, grid, ssugar, sspice, tempssugar, tempsspice, tempi, tempj, i, j
        )
        if d_move == 'yes':
            move = 'yes'
            
    return tempssugar, tempsspice, tempi, tempj, move

def moveagentT(grid, i, j, tempssugar, tempsspice, tempi, tempj, move):
    """Updates physical coordinate position arrays and processes biological metabolic burn."""
    if move == 'yes':
        # Relocate the agent to the new grid coordinate cell
        grid[tempi, tempj] = grid[i, j]
        grid[i, j] = Agent(active=False)
        
        # Harvest localized grid resources and subtract metabolism costs
        grid[tempi, tempj].wealthsugar += tempssugar - grid[tempi, tempj].metsugar
        grid[tempi, tempj].wealthspice += tempsspice - grid[tempi, tempj].metspice
        
        # Check for starvation
        if grid[tempi, tempj].wealthsugar <= 0 or grid[tempi, tempj].wealthspice <= 0:
            grid[tempi, tempj] = Agent(active=False)
    else:
        # Stationary metabolism execution
        grid[i, j].wealthsugar += tempssugar - grid[i, j].metsugar
        grid[i, j].wealthspice += tempsspice - grid[i, j].metspice
        if grid[i, j].wealthsugar <= 0 or grid[i, j].wealthspice <= 0:
            grid[i, j] = Agent(active=False)
            
    return grid

# =============================================================================
# COMMERCE AND TRADING SYSTEM FUNCTIONS
# =============================================================================

def neighborT(u, v, grid, i, j):
    """Executes a structural trading transaction via Marginal Rates of Substitution (MRS)."""
    aptv = 0
    ptv = []
    
    if grid[u, v].active:
        a = grid[i, j]
        b = grid[u, v]
        
        if a.wealthsugar > 0 and a.wealthspice > 0 and b.wealthsugar > 0 and b.wealthspice > 0:
            mtota = a.metspice + a.metsugar
            mtotb = b.metspice + b.metsugar
            
            signalloop = 'yes'
            waold = (a.wealthsugar ** (a.metsugar / mtota)) * (a.wealthspice ** (a.metspice / mtota))
            wbold = (b.wealthsugar ** (b.metsugar / mtotb)) * (b.wealthspice ** (b.metspice / mtotb))
            
            omrsa = (a.wealthspice / a.metspice) / (a.wealthsugar / a.metsugar)
            omrsb = (b.wealthspice / b.metspice) / (b.wealthsugar / b.metsugar)
            
            if omrsa > omrsb:
                signalmrsold = '>'
            elif omrsa < omrsb:
                signalmrsold = '<'
            else:
                signalloop = 'not'
        else:
            signalloop = 'not'
            
        signaltrade = 'not'
        
        while signalloop == 'yes':
            p = (omrsa * omrsb) ** 0.5
            qsu = 1 if p > 1 else 1 / p
            qsp = p if p > 1 else 1
            
            if signalmrsold == '>':
                qsua, qspa, qsub, qspb = qsu, -qsp, -qsu, qsp
            else:
                qsua, qspa, qsub, qspb = -qsu, qsp, qsu, -qsp
                
            nwsua = a.wealthsugar + qsua
            nwspa = a.wealthspice + qspa
            nwsub = b.wealthsugar + qsub
            nwspb = b.wealthspice + qspb
            
            if nwsua > 0 and nwspa > 0 and nwsub > 0 and nwspb > 0:
                wanew = (nwsua ** (a.metsugar / mtota)) * (nwspa ** (a.metspice / mtota))
                wbnew = (nwsub ** (b.metsugar / mtotb)) * (nwspb ** (b.metspice / mtotb))
                
                if wanew > waold and wbnew > wbold:
                    nmrsa = (nwspa / a.metspice) / (nwsua / a.metsugar)
                    nmrsb = (nwspb / b.metspice) / (nwsub / b.metsugar)
                    
                    if nmrsa > nmrsb:
                        signalmrsnew = '>'
                    elif nmrsa < nmrsb:
                        signalmrsnew = '<'
                    else:
                        signalloop = 'not'
                        
                    if signalmrsold == signalmrsnew:
                        signaltrade = 'yes'
                        
                        # Cache localized internal variable values throughout transaction rounds
                        a.wealthsugar, a.wealthspice = nwsua, nwspa
                        b.wealthsugar, b.wealthspice = nwsub, nwspb
                        omrsa, omrsb = nmrsa, nmrsb
                        
                        ptv.append(p)
                        aptv = np.exp(np.mean(np.log(ptv))) # Geometric Mean
                    else:
                        signalloop = 'not'
                else:
                    signalloop = 'not'
            else:
                signalloop = 'not'
                
        # FIXED: Correct allocation bug matching matching wealth categories to proper owners 
        if signaltrade == 'yes':
            grid[i, j].wealthsugar = a.wealthsugar
            grid[i, j].wealthspice = a.wealthspice
            grid[u, v].wealthsugar = b.wealthsugar
            grid[u, v].wealthspice = b.wealthspice

    return aptv, grid

def seeT(i, j, k, grid, size_dim):
    """Searches surrounding perimeter blocks seeking trade partners."""
    pav = []
    avpav = 0
    
    directions = [
        ((i + k) % size_dim, j),
        ((i - k) % size_dim, j),
        (i, (j + k) % size_dim),
        (i, (j - k) % size_dim)
    ]
    
    for idx in np.random.permutation(4):
        u, v = directions[idx]
        aptv, grid = neighborT(u, v, grid, i, j)
        if aptv > 0:
            pav.append(aptv)
            avpav = np.exp(np.mean(np.log(pav))) # Geometric Mean
            
    return avpav, grid

# =============================================================================
# SIMULATION CORE PIPELINE CONTROL EXECUTOR
# =============================================================================
if __name__ == "__main__":
    # Base Environment Configurations Constants
    nruns = 50
    size_dim = 50
    metsugar = 5
    metspice = 5
    vision = 5
    maxsugar = 30
    maxspice = 30
    initwup = 50
    initwlow = 25

    # Run Initialization Phase Sets
    s, ssugar, sspice = initsugarscapeT(size_dim, maxsugar, maxspice)
    grid = initagentsT(size_dim, vision, metsugar, metspice, initwup, initwlow)

    avprruns = np.zeros(nruns)
    axesx = np.arange(1, nruns + 1)

    # Core Sequential Evolution Loop Timeline
    for runs in range(1, nruns + 1):
        prv = [1.0] # Pad with initial value base element to prevent evaluation error crashes
        
        dispagentlocT(grid, size_dim, nruns, runs)
        
        # Scramble spatial processing coordinates sequence randomly
        for i in np.random.permutation(size_dim):
            for j in np.random.permutation(size_dim):
                if grid[i, j].active:
                    
                    tempssugar = ssugar[i, j]
                    tempsspice = sspice[i, j]
                    tempi, tempj = i, j
                    
                    # Execution Cycle Step 1: Movement Engine Process Sequence
                    for k in range(grid[i, j].vision, 0, -1):
                        tempssugar, tempsspice, tempi, tempj, move = seeW(
                            i, j, k, grid, ssugar, sspice, size_dim, tempssugar, tempsspice, tempi, tempj
                        )
                    
                    grid = moveagentT(grid, i, j, tempssugar, tempsspice, tempi, tempj, move)
                    
                    # Execution Cycle Step 2: Commercial Marketplace Trade Systems Sequence
                    if grid[tempi, tempj].active:
                        for k in range(grid[tempi, tempj].vision, 0, -1):
                            avpav, grid = seeT(tempi, tempj, k, grid, size_dim)
                            if avpav > 0:
                                prv.append(avpav)
                                
        # Calculate dynamic Geometric Mean of global market prices for current lifecycle run
        avprv = np.exp(np.mean(np.log(prv)))
        avprruns[runs - 1] = avprv
        print(f"Cycle run {runs:02d}/{nruns:02d} complete. Global Geometric Mean Price: {avprv:.4f}")

    # =============================================================================
    # DIAGNOSTIC TRADE PLOT OUTPUT VISUALIZATION (FIGURE 3)
    # =============================================================================
    plt.figure(3)
    plt.scatter(axesx, avprruns, color='crimson', edgecolors='black', zorder=3)
    plt.plot(axesx, avprruns, color='black', alpha=0.5, linestyle='--', zorder=2)
    plt.title("Sugarscape Market Price Vectors — Aggregate Run Summary")
    plt.xlabel("Timeline Sim Runs / Iterations")
    plt.ylabel("Geometric Mean Market Trading Price")
    
    # FIXED: Replaced rigid aspect ratios so prices map clearly along the axes without squishing
    plt.autoscale(enable=True, axis='both', tight=False)
    plt.grid(True, linestyle=':', alpha=0.6)
    
    # Show all generated visualization figures
    plt.show()