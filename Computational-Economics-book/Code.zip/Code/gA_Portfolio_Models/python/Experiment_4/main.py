import numpy as np
import matplotlib.pyplot as plt

# --- Configuratie & Parameters ---
nruns = 100
popsize = 8
beta = 2
mu = np.array([8, 12, 15])
sigma = np.array([[6, -5, 4], [-5, 17, -11], [4, -11, 24]])
num = 3
clen = num * 8
pmut = 0.5

# --- Functies ---

def initpoprand(clen, popsize):
    # Genereert een populatie van random bit-strings (als integers)
    return np.array([np.random.randint(0, 2**clen) for _ in range(popsize)])

def normport(genepool, popsize, clen, num):
    # Converteert chromosomen naar genormaliseerde portfolio gewichten
    pwm = np.zeros((num, popsize))
    n = int(np.ceil(clen / num))
    mask = (1 << n) - 1
    for i in range(popsize):
        genetemp = int(genepool[i])
        port = np.zeros(num)
        for j in range(num):
            port[num - j - 1] = genetemp & mask
            genetemp >>= n
        # Zorg dat de som 1 is
        port_sum = np.sum(port)
        pwm[:, i] = port / port_sum if port_sum != 0 else 1/num
    return pwm

def fitness_eval(pwm, mu, beta, sigma):
    # Berekent fitness (Return - Variantie)
    pret = pwm.T @ mu
    pvar = np.array([0.5 * beta * pwm[:, j].T @ sigma @ pwm[:, j] for j in range(pwm.shape[1])])
    return pret - pvar

def parentsrand(fit, genepool):
    # Roulette-wiel selectie (gecorrigeerd voor negatieve waarden)
    fit_adj = fit - np.min(fit) + 1e-9
    probs = fit_adj / np.sum(fit_adj)
    idx = np.random.choice(len(genepool), p=probs)
    return genepool[idx]

def crossover(clen, p0, p1):
    crossov = np.random.randint(1, clen)
    mask = (1 << crossov) - 1
    # Wissel bits na crossover-punt
    child0 = (p0 & mask) | (p1 & ~mask & ((1 << clen) - 1))
    child1 = (p1 & mask) | (p0 & ~mask & ((1 << clen) - 1))
    return child0, child1

def mutation(pmut, clen, child):
    if np.random.rand() < pmut:
        idx = np.random.randint(0, clen)
        child ^= (1 << idx)  # Flip bit
    return child

# --- Hoofdprogramma ---

genepool = initpoprand(clen, popsize)
wbest = np.zeros((num, nruns))
fbest = np.zeros(nruns)

for k in range(nruns):
    pwm = normport(genepool, popsize, clen, num)
    fit = fitness_eval(pwm, mu, beta, sigma)
    
    # Sla beste resultaat van deze generatie op
    best_idx = np.argmax(fit)
    wbest[:, k] = pwm[:, best_idx]
    fbest[k] = fit[best_idx]
    
    # Maak nieuwe generatie
    new_genepool = []
    for _ in range(0, popsize, 2):
        p0 = parentsrand(fit, genepool)
        p1 = parentsrand(fit, genepool)
        c0, c1 = crossover(clen, p0, p1)
        new_genepool.extend([mutation(pmut, clen, c0), mutation(pmut, clen, c1)])
    genepool = np.array(new_genepool)

# --- Visualisatie ---
plt.figure(figsize=(12, 5))

# Plot 1: Gewichten
plt.subplot(1, 2, 1)
plt.plot(wbest.T)
plt.title("Evolutie Gewichten")
plt.legend(["Asset 1", "Asset 2", "Asset 3"])

# Plot 2: Fitness
plt.subplot(1, 2, 2)
plt.plot(fbest, 'r')
plt.title("Fitness Verloop")

plt.show()