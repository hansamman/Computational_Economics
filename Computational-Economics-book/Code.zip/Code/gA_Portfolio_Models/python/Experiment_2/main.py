import numpy as np
import matplotlib.pyplot as plt

# --- Parameters ---
nruns = 100
popsize = 8
beta = 2
mu = np.array([8, 12, 15])
sigma = np.array([[6, -5, 4],
                  [-5, 17, -11],
                  [4, -11, 24]])
num = 3
clen = num * 8
pmut = 0.5

# --- Functies ---

def initpoprand_gaportfol(clen, popsize):
    genepool = np.zeros(popsize, dtype=object)
    for j in range(popsize):
        val = 0
        for i in range(clen):
            if np.random.rand() < 0.5:
                val |= (1 << i)
        genepool[j] = val
    return genepool

def normport(genepool, popsize, clen, num):
    pwm = np.zeros((num, popsize))
    n = int(np.ceil(clen / num))
    mask = (1 << n) - 1
    for i in range(popsize):
        genetemp = int(genepool[i])
        port = np.zeros(num)
        for j in range(num):
            port[num - j - 1] = genetemp & mask
            genetemp >>= n
        pwm[:, i] = port / np.sum(port)
    return pwm

def fitness_gaportfol(pwm, mu, popsize, beta, sigma):
    pret = pwm.T @ mu
    pvar = np.array([0.5 * beta * pwm[:, j].T @ sigma @ pwm[:, j] for j in range(popsize)])
    fit = pret - pvar
    topi = np.argmax(fit)
    return fit, pwm[:, topi], fit[topi]

def parentsdet(fit, genepool):
    indices = np.argsort(fit)
    return genepool[indices[-1]], genepool[indices[-2]]

def crossover(clen, parent0, parent1):
    crossov = np.random.randint(0, clen)
    maska = (1 << crossov) - 1
    full_mask = (1 << clen) - 1
    
    child0 = (parent0 & maska) | (parent1 & (full_mask ^ maska))
    child1 = (parent1 & maska) | (parent0 & (full_mask ^ maska))
    return child0, child1

def mutation(pmut, clen, child):
    if np.random.rand() < pmut:
        idx = np.random.randint(0, clen)
        tt = 1 << idx
        # XOR operatie voor het flippen van een bit
        child ^= tt
    return child

# --- Hoofdprogramma ---

genepool = initpoprand_gaportfol(clen, popsize)
wbest = np.zeros((num, nruns))
fbest = np.zeros(nruns)

for k in range(nruns):
    pwm = normport(genepool, popsize, clen, num)
    fit, bestind, bestfit = fitness_gaportfol(pwm, mu, popsize, beta, sigma)
    
    wbest[:, k] = bestind
    fbest[k] = bestfit
    
    parent0, parent1 = parentsdet(fit, genepool)
    child0, child1 = crossover(clen, parent0, parent1)
    
    genenew = np.zeros(popsize, dtype=object)
    for h in range(0, popsize, 2):
        genenew[h] = mutation(pmut, clen, child0)
        genenew[h+1] = mutation(pmut, clen, child1)
    genepool = genenew

# --- Output & Visualisatie ---
print("Best weights (final):", wbest[:, -1])
print("Best fitness values:", fbest)

plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.plot(wbest.T)
plt.title("Optimal Weights")
plt.subplot(1, 2, 2)
plt.plot(fbest)
plt.title("Fitness over Generations")
plt.show()