import numpy as np
import matplotlib.pyplot as plt

# --- 1. Configuratie ---
nruns = 100
popsize = 500  # Even getal voor crossover
beta = 2
mu = np.array([8, 12, 15])
sigma = np.array([[6, -5, 4], [-5, 17, -11], [4, -11, 24]])
num = 3
clen = num * 8
pmut = 0.5

# --- 2. Hulpfuncties ---

def initpoprand(clen, popsize):
    # Genereert random populatie (chromosomen als integers)
    return np.random.randint(0, 2**clen, size=popsize)

def normport(genepool, popsize, clen, num):
    # Converteert bits naar gewichten (som = 1)
    pwm = np.zeros((num, popsize))
    n = int(np.ceil(clen / num))
    mask = (1 << n) - 1
    for i in range(popsize):
        val = int(genepool[i])
        port = np.zeros(num)
        for j in range(num):
            port[num - j - 1] = val & mask
            val >>= n
        pwm[:, i] = port / np.sum(port) if np.sum(port) != 0 else 1/num
    return pwm

def fitnessnc(pwm, mu, beta, sigma, num):
    # Fitness berekening inclusief 'Portfolio Redistribution' logica
    popsize = pwm.shape[1]
    # Redistribution: vervang kleine gewichten door 0
    pwm[pwm < 0.1] = 0
    # Normaliseer opnieuw na het op nul zetten
    pwm /= np.sum(pwm, axis=0)
    
    pret = pwm.T @ mu
    pvar = np.array([0.5 * beta * pwm[:, j].T @ sigma @ pwm[:, j] for j in range(popsize)])
    # Broker kosten
    pbrok = 0.2 * np.ones(num) @ (pwm > 0) + 0.05 * np.sum(pwm, axis=0)
    return pret - pvar - pbrok

def crossover(clen, p0, p1):
    crossov = np.random.randint(1, clen)
    mask = (1 << crossov) - 1
    child0 = (p0 & mask) | (p1 & ~mask & ((1 << clen) - 1))
    child1 = (p1 & mask) | (p0 & ~mask & ((1 << clen) - 1))
    return child0, child1

def mutation(pmut, clen, child):
    if np.random.rand() < pmut:
        idx = np.random.randint(0, clen)
        child ^= (1 << idx)
    return child

# --- 3. Hoofdalgoritme ---
genepool = initpoprand(clen, popsize)
wbest = np.zeros((num, nruns))
fbest = np.zeros(nruns)

for k in range(nruns):
    pwm = normport(genepool, popsize, clen, num)
    fit = fitnessnc(pwm, mu, beta, sigma, num)
    
    # Beste resultaat opslaan
    idx_best = np.argmax(fit)
    wbest[:, k] = pwm[:, idx_best]
    fbest[k] = fit[idx_best]
    
    # Roulette wiel selectie
    fit_adj = fit - fit.min() + 1e-9
    probs = fit_adj / fit_adj.sum()
    
    new_genepool = np.zeros(popsize, dtype=int)
    for h in range(0, popsize, 2):
        i1, i2 = np.random.choice(popsize, 2, p=probs)
        c0, c1 = crossover(clen, genepool[i1], genepool[i2])
        new_genepool[h] = mutation(pmut, clen, c0)
        new_genepool[h+1] = mutation(pmut, clen, c1)
    genepool = new_genepool

# --- 4. Visualisatie ---
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
ax1.plot(wbest.T)
ax1.set_title("Evolutie van Portfolio Gewichten")
ax1.legend(["Asset 1", "Asset 2", "Asset 3"])
ax2.plot(fbest, color='tab:red')
ax2.set_title("Fitness Verloop")
plt.show()