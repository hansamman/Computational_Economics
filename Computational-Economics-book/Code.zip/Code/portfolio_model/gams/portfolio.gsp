{
    "file": "portfolio.gms",
    "name": "portfolio",
    "nodes": [
        {
            "codecMib": 106,
            "file": "portfolio.gms",
            "name": "portfolio.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "file": "portfolio.lst",
            "name": "portfolio.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "path": ".",
    "pf": "",
    "workDir": "."
}
