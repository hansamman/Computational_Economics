/*
 * MATLAB Compiler: 2.1
 * Date: Sun Oct 12 22:31:48 2008
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-x" "-W" "mex" "-L" "C"
 * "-t" "-T" "link:mexlibrary" "libmatlbmx.mlib" "dcri1.m" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __dcri1_h
#define __dcri1_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_dcri1(void);
extern void TerminateModule_dcri1(void);
extern _mexLocalFunctionTable _local_function_table_dcri1;

extern mxArray * mlfDcri1(mxArray * x, mxArray * P);
extern void mlxDcri1(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
