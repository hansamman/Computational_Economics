/*
 * MATLAB Compiler: 2.1
 * Date: Sun Oct 12 22:31:48 2008
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-x" "-W" "mex" "-L" "C"
 * "-t" "-T" "link:mexlibrary" "libmatlbmx.mlib" "dcri1.m" 
 */
#include "dcri1.h"
#include "libmatlbm.h"

extern mxArray * mu;
extern mxArray * sigma;

static mxChar _array1_[128] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'd', 'c', 'r', 'i', '1',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '7', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'd', 'c', 'r',
                                'i', '1', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'o',
                                'u', 't', 'p', 'u', 't', 's', ' ', '(', '1',
                                ')', '.' };
static mxArray * _mxarray0_;

static mxChar _array3_[127] = { 'R', 'u', 'n', '-', 't', 'i', 'm', 'e', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'i',
                                'l', 'e', ':', ' ', 'd', 'c', 'r', 'i', '1',
                                ' ', 'L', 'i', 'n', 'e', ':', ' ', '7', ' ',
                                'C', 'o', 'l', 'u', 'm', 'n', ':', ' ', '1',
                                ' ', 'T', 'h', 'e', ' ', 'f', 'u', 'n', 'c',
                                't', 'i', 'o', 'n', ' ', '"', 'd', 'c', 'r',
                                'i', '1', '"', ' ', 'w', 'a', 's', ' ', 'c',
                                'a', 'l', 'l', 'e', 'd', ' ', 'w', 'i', 't',
                                'h', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'h', 'e', ' ', 'd', 'e',
                                'c', 'l', 'a', 'r', 'e', 'd', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'i',
                                'n', 'p', 'u', 't', 's', ' ', '(', '2', ')',
                                '.' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;

void InitializeModule_dcri1(void) {
    _mxarray0_ = mclInitializeString(128, _array1_);
    _mxarray2_ = mclInitializeString(127, _array3_);
    _mxarray4_ = mclInitializeDouble(0.0);
    _mxarray5_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray6_ = mclInitializeDouble(.5);
}

void TerminateModule_dcri1(void) {
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mdcri1(int nargout_, mxArray * x, mxArray * P);

_mexLocalFunctionTable _local_function_table_dcri1
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfDcri1" contains the normal interface for the "dcri1"
 * M-function from file "C:\Users\amman\Desktop\15\examples\chapter8\dcri1.m"
 * (lines 1-24). This function processes any input arguments and passes them to
 * the implementation version of the function, appearing above.
 */
mxArray * mlfDcri1(mxArray * x, mxArray * P) {
    int nargout = 1;
    mxArray * z = mclGetUninitializedArray();
    mlfEnterNewContext(0, 2, x, P);
    z = Mdcri1(nargout, x, P);
    mlfRestorePreviousContext(0, 2, x, P);
    return mlfReturnValue(z);
}

/*
 * The function "mlxDcri1" contains the feval interface for the "dcri1"
 * M-function from file "C:\Users\amman\Desktop\15\examples\chapter8\dcri1.m"
 * (lines 1-24). The feval function calls the implementation version of dcri1
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxDcri1(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(_mxarray0_);
    }
    if (nrhs > 2) {
        mlfError(_mxarray2_);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = mclGetUninitializedArray();
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mdcri1(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mdcri1" is the implementation version of the "dcri1"
 * M-function from file "C:\Users\amman\Desktop\15\examples\chapter8\dcri1.m"
 * (lines 1-24). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * % Titlle: Quadratic-Linear Programming for Mean Variance Portfolio Analysis
 * % Function Name: dcri1.m
 * % by Miwa Hattori 
 * %The first formulation of the criterion function for mean-variance portfolio selection model.
 * %Defines the expected mean return, net of variance costs, which is to be maximized.
 * 
 * function [z] = dcri1(x, P) 
 */
static mxArray * Mdcri1(int nargout_, mxArray * x, mxArray * P) {
    mexLocalFunctionTable save_local_function_table_ = mclSetCurrentLocalFunctionTable(
                                                         &_local_function_table_dcri1);
    mxArray * z = mclGetUninitializedArray();
    mxArray * j = mclGetUninitializedArray();
    mxArray * temp = mclGetUninitializedArray();
    mxArray * i = mclGetUninitializedArray();
    mxArray * N = mclGetUninitializedArray();
    mxArray * BETA = mclGetUninitializedArray();
    mxArray * THETA = mclGetUninitializedArray();
    mxArray * ans = mclGetUninitializedArray();
    mclCopyArray(&x);
    mclCopyArray(&P);
    /*
     * 
     * global mu; global sigma;
     * THETA=P(1);
     */
    mlfAssign(&THETA, mclIntArrayRef1(mclVsa(P, "P"), 1));
    /*
     * BETA=P(2);
     */
    mlfAssign(&BETA, mclIntArrayRef1(mclVsa(P, "P"), 2));
    /*
     * N=P(3);
     */
    mlfAssign(&N, mclIntArrayRef1(mclVsa(P, "P"), 3));
    /*
     * 
     * z=0;
     */
    mlfAssign(&z, _mxarray4_);
    /*
     * for i=1:N;
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(N, "N"));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray5_);
        } else {
            /*
             * temp=0;
             * for j=1:N;
             * temp=temp+BETA*sigma(i,j)*x(j);
             * end;
             * z=z+mu(i)*x(i)-0.5*x(i)*temp;
             * end;
             */
            for (; ; ) {
                mlfAssign(&temp, _mxarray4_);
                {
                    int v_0 = mclForIntStart(1);
                    int e_0 = mclForIntEnd(mclVv(N, "N"));
                    if (v_0 > e_0) {
                        mlfAssign(&j, _mxarray5_);
                    } else {
                        for (; ; ) {
                            mlfAssign(
                              &temp,
                              mclPlus(
                                mclVv(temp, "temp"),
                                mclMtimes(
                                  mclMtimes(
                                    mclVv(BETA, "BETA"),
                                    mclVe(
                                      mlfIndexRef(
                                        mclVg(&sigma, "sigma"),
                                        "(?,?)",
                                        mlfScalar(v_),
                                        mlfScalar(v_0)))),
                                  mclVe(
                                    mclIntArrayRef1(mclVsa(x, "x"), v_0)))));
                            if (v_0 == e_0) {
                                break;
                            }
                            ++v_0;
                        }
                        mlfAssign(&j, mlfScalar(v_0));
                    }
                }
                mlfAssign(
                  &z,
                  mclMinus(
                    mclPlus(
                      mclVv(z, "z"),
                      mclMtimes(
                        mclVe(
                          mlfIndexRef(mclVg(&mu, "mu"), "(?)", mlfScalar(v_))),
                        mclVe(mclIntArrayRef1(mclVsa(x, "x"), v_)))),
                    mclMtimes(
                      mclMtimes(
                        _mxarray6_, mclVe(mclIntArrayRef1(mclVsa(x, "x"), v_))),
                      mclVv(temp, "temp"))));
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    /*
     * 
     * z=-z;           % Matlab only has a subroutine to solve constrained MINIMIZATION problems.
     */
    mlfAssign(&z, mclUminus(mclVv(z, "z")));
    mclValidateOutput(z, 1, nargout_, "z", "dcri1");
    mxDestroyArray(ans);
    mxDestroyArray(THETA);
    mxDestroyArray(BETA);
    mxDestroyArray(N);
    mxDestroyArray(i);
    mxDestroyArray(temp);
    mxDestroyArray(j);
    mxDestroyArray(P);
    mxDestroyArray(x);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return z;
    /*
     * % We solve a maximization problem by minimizing the negative of the objective function.
     */
}
