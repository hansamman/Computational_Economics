import numpy as np
from scipy.optimize import minimize
import matplotlib.pyplot as plt

# Parameters
N = 3
beta = 2
mu = np.array([8, 12, 15])
sigma = np.array([[6, -5, 4], 
                  [-5, 17, -11], 
                  [4, -11, 24]])

# Constraints
Aeq = np.array([[1, 1, 1]])
beq = np.array([1])
bounds = [(0, 1), (0, 1), (0, 1)]

# Objective function for Formulation 1 (Maximize return net of risk)
def objective1(x):
    return -(np.dot(mu, x) - 0.5 * beta * np.dot(x.T, np.dot(sigma, x)))

# Run optimization for various risk aversion levels to map the frontier
risk_aversion_levels = np.linspace(0.1, 5, 20)
port_returns = []
port_variances = []

for b in risk_aversion_levels:
    res = minimize(lambda x: -(np.dot(mu, x) - 0.5 * b * np.dot(x.T, np.dot(sigma, x))),
                   x0=np.ones(N)/N, method='SLSQP', bounds=bounds, 
                   constraints={'type': 'eq', 'fun': lambda x: np.sum(x) - 1})
    if res.success:
        ret = np.dot(mu, res.x)
        var = np.dot(res.x.T, np.dot(sigma, res.x))
        port_returns.append(ret)
        port_variances.append(var)

# Plotting the Efficient Frontier
plt.figure(figsize=(10, 6))
plt.scatter(port_variances, port_returns, c=risk_aversion_levels, cmap='viridis')
plt.colorbar(label='Risk Aversion (beta)')
plt.title('Efficient Frontier - Markowitz Portfolio Optimization')
plt.xlabel('Portfolio Variance')
plt.ylabel('Expected Return')
plt.grid(True)
plt.show()