import numpy as np
from scipy.optimize import minimize

# Parameters
N = 3
beta = 2
mu = np.array([8, 12, 15])
sigma = np.array([[6, -5, 4], 
                  [-5, 17, -11], 
                  [4, -11, 24]])

# Constraints
# Sum of weights = 1
Aeq = np.array([[1, 1, 1]])
beq = np.array([1])
# Weights >= 0
bounds = [(0, None), (0, None), (0, None)]

# Formulation 1: Maximize (mu * x - 0.5 * beta * x' * sigma * x)
# Equivalent to minimizing -(mu * x - 0.5 * beta * x' * sigma * x)
def dcri1(x):
    z = np.dot(mu, x) - 0.5 * beta * np.dot(x.T, np.dot(sigma, x))
    return -z

# Formulation 2: Minimize (0.5 * beta * y' * sigma * y)
# Subject to: y' * mu >= theta
theta = 10
def dcri2(y):
    z = 0.5 * beta * np.dot(y.T, np.dot(sigma, y))
    return z

def constraint_formulation2(y):
    return np.dot(y, mu) - theta

# Initial guess
x0 = np.ones(N) / N

# Run Optimization 1
result1 = minimize(dcri1, x0, method='SLSQP', bounds=bounds, 
                   constraints={'type': 'eq', 'fun': lambda x: np.sum(x) - 1})

# Run Optimization 2
result2 = minimize(dcri2, x0, method='SLSQP', bounds=bounds, 
                   constraints=[{'type': 'eq', 'fun': lambda y: np.sum(y) - 1},
                                {'type': 'ineq', 'fun': constraint_formulation2}])

print("Optimization 1 Results (Weights):", result1.x)
print("Optimization 2 Results (Weights):", result2.x)