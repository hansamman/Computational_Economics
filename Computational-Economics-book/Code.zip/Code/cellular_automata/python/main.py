import numpy as np
import matplotlib.pyplot as plt
import matplotlib

# Configuration
SIZE = 49
NRUNS = 25
B = 1.85  # Temptation to defect

def create_agent():
    """Initializes a dictionary representing an agent's state."""
    return {
        'action_present': 1,  # 1: Cooperator, 0: Defector
        'action_previous': 1,
        'accumpayoffs': 0,
        'color': 4
    }

# Initialize grid
grid = np.array([[create_agent() for _ in range(SIZE)] for _ in range(SIZE)], dtype=object)

# Place initial defector at center
center = SIZE // 2
grid[center, center].update({'action_present': 0, 'action_previous': 0, 'color': 1})

def play_games(grid, b):
    """Calculates payoffs based on interactions with neighbors."""
    for row in grid:
        for agent in row:
            agent['accumpayoffs'] = 0
            
    for i in range(SIZE):
        for j in range(SIZE):
            for u in [-1, 0, 1]:
                for v in [-1, 0, 1]:
                    # Periodic boundaries (torus)
                    iu, jv = (i + u) % SIZE, (j + v) % SIZE
                    p1 = grid[i, j]['action_present']
                    p2 = grid[iu, jv]['action_present']
                    
                    if p1 == 0 and p2 == 1:
                        grid[i, j]['accumpayoffs'] += b
                    elif p1 == 1 and p2 == 1:
                        grid[i, j]['accumpayoffs'] += 1

def adopt_best(grid):
    """Agents adopt the action of the neighbor with the highest payoff."""
    new_actions = np.zeros((SIZE, SIZE), dtype=int)
    for i in range(SIZE):
        for j in range(SIZE):
            best_payoff = -1
            best_action = grid[i, j]['action_present']
            
            for u in [-1, 0, 1]:
                for v in [-1, 0, 1]:
                    neighbor = grid[(i + u) % SIZE, (j + v) % SIZE]
                    if neighbor['accumpayoffs'] > best_payoff:
                        best_payoff = neighbor['accumpayoffs']
                        best_action = neighbor['action_present']
            new_actions[i, j] = best_action
            
    for i in range(SIZE):
        for j in range(SIZE):
            grid[i, j]['action_previous'] = grid[i, j]['action_present']
            grid[i, j]['action_present'] = new_actions[i, j]

def update_colors(grid):
    """Updates agent colors based on their state transition."""
    for i in range(SIZE):
        for j in range(SIZE):
            prev, curr = grid[i, j]['action_previous'], grid[i, j]['action_present']
            if prev == 0 and curr == 0: grid[i, j]['color'] = 1 # Defector/Defector
            elif prev == 0 and curr == 1: grid[i, j]['color'] = 2 # Defector/Cooperator
            elif prev == 1 and curr == 0: grid[i, j]['color'] = 3 # Cooperator/Defector
            elif prev == 1 and curr == 1: grid[i, j]['color'] = 4 # Cooperator/Cooperator

# Main Loop
fig, axes = plt.subplots(5, 5, figsize=(10, 10))
axes = axes.flatten()

# Setup custom discrete colormap
cmap = matplotlib.colormaps['viridis'].resampled(4)

for run in range(NRUNS):
    # Visualize
    colors = np.array([[agent['color'] for agent in row] for row in grid])
    axes[run].imshow(colors, cmap=cmap)
    axes[run].axis('off')
    axes[run].set_title(f"Run {run+1}", fontsize=8)
    
    # Process
    play_games(grid, B)
    adopt_best(grid)
    update_colors(grid)

plt.tight_layout()
plt.show()