{
    "file": "trnsport.gms",
    "name": "trnsport",
    "nodes": [
        {
            "codecMib": 106,
            "file": "trnsport.gms",
            "name": "trnsport.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "file": "trnsport.lst",
            "name": "trnsport.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "path": ".",
    "pf": "",
    "workDir": "."
}
