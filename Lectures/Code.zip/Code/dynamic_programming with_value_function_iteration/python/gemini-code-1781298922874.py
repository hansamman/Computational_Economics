import numpy as np
import matplotlib.pyplot as plt

# Parameters
alpha = 0.33
beta = 0.98
theta = 0.3
tau = 0.5
delta = 0.1
k0 = 0.1
kN = 2.1
n = 100
step = (kN - k0) / (n - 1)
k_grid = np.linspace(k0, kN, n)

iterlim = 5
tolera = 0.000001

z_low = 0.90
z_high = 1.10

# Probability transition matrix
P = np.array([[0.5, 0.5],  # Low to [Low, High]
              [0.1, 0.9]]) # High to [Low, High]

# Grids
y_grid_l = z_low * theta * (k_grid**alpha)
y_grid_h = z_high * theta * (k_grid**alpha)

# Meshes: kt_mesh (rows), kt1_mesh (cols)
kt_mesh = np.tile(k_grid, (n, 1))
kt1_mesh = np.tile(k_grid, (n, 1)).T
i_mesh = kt1_mesh - (1 - delta) * kt_mesh

# Consumption
c_mesh_l = np.maximum(np.tile(y_grid_l, (n, 1)) - i_mesh, 0)
c_mesh_h = np.maximum(np.tile(y_grid_h, (n, 1)) - i_mesh, 0)

# Utility
def get_utility(c):
    u = (1 / (1 - tau)) * (c**(1 - tau))
    u[c == 0] = -10
    return u

u_mesh_l = get_utility(c_mesh_l)
u_mesh_h = get_utility(c_mesh_h)

# Initialization
Vlast_l = (1 / (1 - tau)) * (y_grid_l**(1 - tau))
Vlast_h = (1 / (1 - tau)) * (y_grid_h**(1 - tau))

# Iteration
tol = 1
iter = 0
while (tol > tolera) and (iter < iterlim):
    iter += 1
    
    # Bellman equation
    V_l = u_mesh_l + beta * (P[0, 0] * Vlast_l + P[0, 1] * Vlast_h)
    V_h = u_mesh_h + beta * (P[1, 0] * Vlast_l + P[1, 1] * Vlast_h)
    
    VV_l = np.max(V_l, axis=0)
    VV_h = np.max(V_h, axis=0)
    
    I_l = np.argmax(V_l, axis=0)
    I_h = np.argmax(V_h, axis=0)
    
    tol = max(np.max(np.abs(VV_l - Vlast_l)), np.max(np.abs(VV_h - Vlast_h)))
    Vlast_l, Vlast_h = VV_l, VV_h

# Plotting
plt.figure(figsize=(8, 5))
index = np.arange(n)
plt.plot(index, index, label='Steady State')
plt.plot(index, I_l, '--', label='Decision Rule Low')
plt.plot(index, I_h, ':', label='Decision Rule High')
plt.title('Path of capital')
plt.legend()
plt.show()