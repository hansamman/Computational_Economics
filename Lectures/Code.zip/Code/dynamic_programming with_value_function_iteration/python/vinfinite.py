#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 12 22:55:41 2026

@author: hansamman
"""

import numpy as np
import matplotlib.pyplot as plt

# --- Parameters ---
alpha = 0.33
beta = 0.98
theta = 0.3
tau = 0.5
delta = 0.1
k0, kN = 0.1, 2.1
n = 100
k_grid = np.linspace(k0, kN, n)

# Settings
iterlim = 5
tolera = 0.000001

# --- Mesh Setup ---
# Broadcasting creates an N x N mesh without manual aux matrices
kt = k_grid[np.newaxis, :]  # Shape (1, 100)
kt1 = k_grid[:, np.newaxis] # Shape (100, 1)

# Production and Investment
y_mesh = theta * (kt**alpha)
i_mesh = kt1 - (1 - delta) * kt

# Consumption and Utility
c_mesh = y_mesh - i_mesh
c_mesh[c_mesh < 0] = 0  # Mask negative consumption

u_mesh = (1 / (1 - tau)) * (c_mesh**(1 - tau))
u_mesh[c_mesh == 0] = -10  # Penalty for invalid states

# --- Initial Guess ---
# Starting with zero investment
Vlast = (1 / (1 - tau)) * ((theta * (k_grid**alpha))**(1 - tau))

# --- Value Function Iteration ---
tol = 1.0
iter = 0

while (tol > tolera) and (iter < iterlim):
    iter += 1
    
    # Bellman equation: V = U(c) + beta * V_next
    # We broadcast Vlast to create the N x N value matrix
    V = u_mesh + beta * Vlast[np.newaxis, :]
    
    # Identify the maximum value and the optimal policy index
    VV = np.max(V, axis=1)
    I = np.argmax(V, axis=1)
    
    # Check convergence
    tol = np.max(np.abs(VV - Vlast))
    Vlast = VV

print(f"Converged after {iter} iterations. Final tolerance: {tol:.2e}")

# --- Plotting ---
index = np.arange(1, n + 1)
plt.figure(figsize=(8, 5))
plt.plot(index, index, '-', label='steady state')
plt.plot(index, I + 1, '--', label='decision rule') # +1 for 1-based index matching
plt.title('Path of capital')
plt.legend()
plt.grid(True)
plt.show()