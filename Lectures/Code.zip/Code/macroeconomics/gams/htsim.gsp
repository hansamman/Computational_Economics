{
    "file": "htsim.gms",
    "name": "htsim",
    "nodes": [
        {
            "codecMib": 106,
            "file": "htsim.gms",
            "name": "htsim.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "file": "htsim.lst",
            "name": "htsim.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "path": ".",
    "pf": "",
    "workDir": "."
}
